// ../../node_modules/.bun/@bridgething+extension@0.14.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder2 = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder2.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder2.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.14.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.14.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.14.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.14.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run2) {
    try {
      return run2();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.14.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// src/protocol.ts
var MEDIA_APPS = ["Spotify", "Music"];
var MEDIA_COMMANDS = ["playpause", "next", "previous"];
var CONTROLS = [
  { id: "mic", label: "Mute mic", kind: "control" },
  { id: "mute", label: "Mute sound", kind: "control" },
  { id: "screenshot", label: "Screenshot", kind: "control" },
  { id: "display-sleep", label: "Lock screen", kind: "control" },
  { id: "mission", label: "Mission Control", kind: "control" },
  { id: "awake", label: "Keep awake", kind: "control" },
  { id: "dark", label: "Dark mode", kind: "control" },
  { id: "desktop", label: "Show desktop", kind: "control" },
  { id: "wifi", label: "Wi-Fi", kind: "control" },
  { id: "bluetooth", label: "Bluetooth", kind: "control" },
  { id: "battery", label: "Battery", kind: "control" },
  { id: "focus", label: "Focus", kind: "control" },
  { id: "screensaver", label: "Screen saver", kind: "control" },
  { id: "quit", label: "Quit app", kind: "control" },
  { id: "brightness", label: "Brightness", kind: "control" },
  { id: "trash", label: "Empty Trash", kind: "control" },
  { id: "sleep", label: "Sleep Mac", kind: "control" }
];
var FOCUS_SHORTCUT = "Toggle Focus";
function readBattery(text2) {
  const m = /(\d+)%;\s*([^;]+);?\s*([^\n]*)/.exec(text2);
  if (!m) return null;
  const status = m[2].trim().toLowerCase();
  const left = /(\d+:\d+) remaining/.exec(m[3]);
  return { percent: Number(m[1]), charging: status === "charging", plugged: /'AC Power'/.test(text2), remaining: left ? left[1] : null };
}
function categoryOf(uti, path) {
  if (path.includes("/Utilities/")) return "Utilities";
  if (!uti) return "Other";
  const kind = uti.replace(/^public\.app-category\./, "");
  if (kind === "games" || kind.endsWith("-games")) return "Games";
  const named = {
    "graphics-design": "Graphics & Design",
    "healthcare-fitness": "Health & Fitness",
    "social-networking": "Social",
    "developer-tools": "Developer Tools"
  };
  return named[kind] ?? kind.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}

// extension/main.ts
var decoder = new TextDecoder();
var CATALOG_EVERY_MS = 5 * 6e4;
var STATE_EVERY_MS = 3e3;
var EXTRAS_EVERY_MS = 15e3;
var CLIP_EVERY_MS = 2e3;
var APP_DIRS = ["/Applications", "/System/Applications", "/System/Applications/Utilities"];
var ICONS_PER_MESSAGE = 16;
var ICON_SCRIPT = `ObjC.import('AppKit');
function run(argv) {
  const out = {};
  for (const path of argv) {
    const icon = $.NSWorkspace.sharedWorkspace.iconForFile(path);
    const rep = $.NSBitmapImageRep.alloc.initWithBitmapDataPlanesPixelsWidePixelsHighBitsPerSampleSamplesPerPixelHasAlphaIsPlanarColorSpaceNameBytesPerRowBitsPerPixel(null, 96, 96, 8, 4, true, false, $.NSDeviceRGBColorSpace, 0, 0);
    $.NSGraphicsContext.saveGraphicsState;
    $.NSGraphicsContext.setCurrentContext($.NSGraphicsContext.graphicsContextWithBitmapImageRep(rep));
    icon.drawInRectFromRectOperationFraction($.NSMakeRect(0, 0, 96, 96), $.NSZeroRect, $.NSCompositingOperationSourceOver, 1);
    $.NSGraphicsContext.restoreGraphicsState;
    out[path] = ObjC.unwrap(rep.representationUsingTypeProperties($.NSBitmapImageFileTypePNG, $()).base64EncodedStringWithOptions(0));
  }
  return JSON.stringify(out);
}`;
var META_SCRIPT = `ObjC.import('Foundation');
function run(argv) {
  const out = {};
  for (const path of argv) {
    const bundle = $.NSBundle.bundleWithPath(path);
    const kind = bundle.isNil() ? null : bundle.objectForInfoDictionaryKey('LSApplicationCategoryType');
    const item = $.NSMetadataItem.alloc.initWithURL($.NSURL.fileURLWithPath(path));
    const used = item.isNil() ? null : item.valueForAttribute('kMDItemLastUsedDate');
    out[path] = { kind: kind && !kind.isNil() ? ObjC.unwrap(kind) : null, used: used && !used.isNil() ? Math.round(used.timeIntervalSince1970 * 1000) : 0 };
  }
  return JSON.stringify(out);
}`;
var STATE_SCRIPT = `ObjC.import('AppKit');
function run() {
  const me = Application.currentApplication();
  me.includeStandardAdditions = true;
  const v = me.getVolumeSettings();
  let media = null;
  for (const name of ${JSON.stringify(MEDIA_APPS)}) {
    try {
      const app = Application(name);
      if (!app.running()) continue;
      const state = app.playerState();
      if (state === 'stopped') continue;
      const track = app.currentTrack;
      const found = { app: name, title: track.name(), artist: track.artist(), playing: state === 'playing' };
      if (!media || found.playing) media = found;
    } catch (e) {}
  }
  const fa = $.NSWorkspace.sharedWorkspace.frontmostApplication;
  const front = fa.isNil() ? null : { name: ObjC.unwrap(fa.localizedName), file: fa.bundleURL.isNil() ? '' : ObjC.unwrap(fa.bundleURL.path).split('/').pop().replace(/\\.app$/, '') };
  const pb = $.NSPasteboard.generalPasteboard;
  const types = ObjC.deepUnwrap(pb.types) || [];
  let clip = { kind: 'empty', text: null };
  if (types.includes('org.nspasteboard.ConcealedType')) clip = { kind: 'hidden', text: null };
  else {
    const s = pb.stringForType($.NSPasteboardTypeString);
    if (!s.isNil()) clip = { kind: 'text', text: ObjC.unwrap(s).slice(0, 240) };
    else if (types.some(t => /png|tiff|jpeg/i.test(t))) clip = { kind: 'image', text: null };
  }
  return JSON.stringify({ volume: v.outputVolume, muted: v.outputMuted, input: v.inputVolume, media, front, clip });
}`;
var HIDE_SCRIPT = `function run() {
  const se = Application('System Events');
  const names = se.applicationProcesses.whose({ visible: true, backgroundOnly: false }).name().filter(n => n !== 'Finder');
  for (const n of names) se.applicationProcesses.byName(n).visible = false;
  return JSON.stringify(names);
}`;
var SHOW_SCRIPT = `function run(argv) {
  const se = Application('System Events');
  for (const n of argv) try { se.applicationProcesses.byName(n).visible = true; } catch (e) {}
}`;
var MENU_SCRIPT = `function run() {
  const se = Application('System Events');
  const p = se.applicationProcesses.whose({ frontmost: true })[0];
  const out = [];
  const bars = p.menuBars[0].menuBarItems;
  const menus = bars.name();
  for (let i = 1; i < menus.length; i++) {
    try {
      const items = bars[i].menus[0].menuItems;
      const titles = items.name();
      const keys = items.attributes.byName('AXMenuItemCmdChar').value();
      const mods = items.attributes.byName('AXMenuItemCmdModifiers').value();
      const enabled = items.enabled();
      for (let j = 0; j < titles.length; j++)
        if (titles[j] && keys[j]) out.push({ menu: menus[i], title: titles[j], key: keys[j], mods: mods[j] || 0, enabled: enabled[j] });
    } catch (e) {}
  }
  return JSON.stringify({ app: p.name(), items: out });
}`;
var QUIT_APP_SCRIPT = `ObjC.import('AppKit');
function run(argv) {
  for (const a of ObjC.unwrap($.NSWorkspace.sharedWorkspace.runningApplications)) {
    if (a.bundleURL.isNil() || ObjC.unwrap(a.bundleURL.path) !== argv[0]) continue;
    const name = ObjC.unwrap(a.localizedName);
    if (name === 'Finder' || /bridgething/i.test(name)) return '';
    return a.terminate ? 'ok' : '';
  }
  return '';
}`;
var PRESS_SCRIPT = `function run(argv) {
  const p = Application('System Events').applicationProcesses.byName(argv[0]);
  p.frontmost = true;
  p.menuBars[0].menuBarItems.byName(argv[1]).menus[0].menuItems.byName(argv[2]).click();
  return 'ok';
}`;
var KEYS_EVERY_MS = 3e4;
var COPY_SCRIPT = `ObjC.import('AppKit');
function run(argv) {
  const pb = $.NSPasteboard.generalPasteboard;
  pb.clearContents;
  return pb.setStringForType(argv[0], $.NSPasteboardTypeString) ? 'ok' : '';
}`;
var CLIP_SCRIPT = `ObjC.import('AppKit');
function run() {
  const pb = $.NSPasteboard.generalPasteboard;
  const types = ObjC.deepUnwrap(pb.types) || [];
  if (types.includes('org.nspasteboard.ConcealedType') || types.includes('org.nspasteboard.TransientType')) return '';
  const s = pb.stringForType($.NSPasteboardTypeString);
  return s.isNil() ? '' : JSON.stringify(ObjC.unwrap(s));
}`;
var CLIPS_KEPT = 25;
var CLIP_MAX = 1e4;
var RUNNING_SCRIPT = `ObjC.import('AppKit');
function run() {
  const out = [];
  for (const a of ObjC.unwrap($.NSWorkspace.sharedWorkspace.runningApplications)) {
    if (a.activationPolicy !== $.NSApplicationActivationPolicyRegular || a.bundleURL.isNil()) continue;
    out.push({ name: ObjC.unwrap(a.localizedName), path: ObjC.unwrap(a.bundleURL.path), active: a.active, hidden: a.hidden });
  }
  out.sort((x, y) => (y.active ? 1 : 0) - (x.active ? 1 : 0));
  return JSON.stringify(out);
}`;
var QUIT_SCRIPT = `function run() {
  const front = Application('System Events').applicationProcesses.whose({ frontmost: true })[0];
  const name = front.name();
  if (name === 'Finder' || /bridgething/i.test(name)) return '';
  Application(name).quit();
  return name;
}`;
var MEDIA_SCRIPT = `function run(argv) {
  const app = Application(argv[0]);
  if (argv[1] === 'playpause') app.playpause();
  else if (argv[1] === 'next') app.nextTrack();
  else if (argv[1] === 'previous') app.previousTrack();
}`;
async function run(binary2, args, timeoutMs = 8e3) {
  try {
    const { success, stdout } = await new Deno.Command(binary2, {
      args,
      stdout: "piped",
      stderr: "null",
      stdin: "null",
      signal: AbortSignal.timeout(timeoutMs)
    }).output();
    return success ? decoder.decode(stdout) : null;
  } catch {
    return null;
  }
}
var logWarn = () => {
};
async function capture(args) {
  try {
    const { success, stderr } = await new Deno.Command("/usr/sbin/screencapture", { args, stdout: "null", stderr: "piped", stdin: "null", signal: AbortSignal.timeout(8e3) }).output();
    if (!success) logWarn(`screencapture ${args.join(" ")} failed: ${decoder.decode(stderr).trim() || "no reason given"}`);
    return success;
  } catch (err) {
    logWarn(`screencapture could not start: ${err}`);
    return false;
  }
}
var osa = (...lines2) => run("/usr/bin/osascript", lines2.flatMap((line) => ["-e", line]));
var wifiDevice;
async function readExtras(awake) {
  if (wifiDevice === void 0) {
    const ports = await run("/usr/sbin/networksetup", ["-listallhardwareports"]) ?? "";
    wifiDevice = /Hardware Port: Wi-Fi\nDevice: (\S+)/.exec(ports)?.[1] ?? null;
  }
  const [power, summary, ip, style, batt, bt] = await Promise.all([
    wifiDevice ? run("/usr/sbin/networksetup", ["-getairportpower", wifiDevice]) : null,
    wifiDevice ? run("/usr/sbin/ipconfig", ["getsummary", wifiDevice]) : null,
    wifiDevice ? run("/usr/sbin/ipconfig", ["getifaddr", wifiDevice]) : null,
    // the key is missing in light mode, which reads as a failed command
    run("/usr/bin/defaults", ["read", "-g", "AppleInterfaceStyle"]),
    run("/usr/bin/pmset", ["-g", "batt"]),
    jxa(BLUETOOTH_SCRIPT)
  ]);
  let bluetooth = null;
  try {
    bluetooth = bt ? JSON.parse(bt) : null;
  } catch {
  }
  return {
    awake,
    wifi: power === null ? null : /: On/.test(power),
    // macos writes <redacted> in place of the name for a process it has not given location access
    network: (() => {
      const name = /^\s*SSID : (.+)$/m.exec(summary ?? "")?.[1]?.trim();
      return name && name !== "<redacted>" ? name : null;
    })(),
    ip: ip?.trim() || null,
    dark: (style ?? "").trim() === "Dark",
    battery: batt ? readBattery(batt) : null,
    bluetooth
  };
}
var BLUETOOTH_SCRIPT = `ObjC.import('IOBluetooth');
function run() {
  const paired = ObjC.unwrap($.IOBluetoothDevice.pairedDevices) || [];
  return JSON.stringify({
    on: $.IOBluetoothHostController.defaultController.powerState === 1,
    devices: paired.filter(d => d.isConnected).map(d => ObjC.unwrap(d.name)),
  });
}`;
var jxa = (script, args = [], timeoutMs = 8e3) => run("/usr/bin/osascript", ["-l", "JavaScript", "-e", script, ...args], timeoutMs);
async function readState() {
  try {
    const s = JSON.parse(await jxa(STATE_SCRIPT) ?? "{}");
    return { volume: Number(s.volume) || 0, muted: s.muted === true, micMuted: Number(s.input) === 0, input: Number(s.input) || 0, media: s.media ?? null, front: s.front ?? null, clip: s.clip ?? { kind: "empty", text: null } };
  } catch {
    return { volume: 0, muted: false, micMuted: false, input: 0, media: null, front: null, clip: { kind: "empty", text: null } };
  }
}
var STARTER = /^(starter shortcuts|phím tắt khởi đầu)$/i;
var UNTITLED = /^New Shortcut( \d+)?$/;
var lines = (out) => (out ?? "").split("\n").filter((s) => s.trim());
async function listShortcuts() {
  const [all, folders] = await Promise.all([run("/usr/bin/shortcuts", ["list"]), run("/usr/bin/shortcuts", ["list", "--folders"])]);
  const starters = new Set(
    (await Promise.all(lines(folders).filter((f) => STARTER.test(f.trim())).map((f) => run("/usr/bin/shortcuts", ["list", "--folder-name", f])))).flatMap(lines)
  );
  return lines(all).filter((name) => !starters.has(name) && !UNTITLED.test(name.trim()));
}
async function listApps() {
  const found = /* @__PURE__ */ new Map();
  for (const dir of APP_DIRS) {
    try {
      for await (const entry of Deno.readDir(dir)) {
        const name = entry.name.slice(0, -4);
        if (entry.name.endsWith(".app") && !found.has(name)) found.set(name, `${dir}/${entry.name}`);
      }
    } catch {
    }
  }
  return new Map([...found].sort(([a], [b]) => a.localeCompare(b)));
}
async function jxaJson(script, paths) {
  if (!paths.length) return {};
  try {
    return JSON.parse(await jxa(script, paths, 3e4) ?? "{}");
  } catch {
    return {};
  }
}
var timers = [];
var stopAwake = () => {
};
defineExtension({
  start(ctx) {
    logWarn = (...args) => ctx.log.warn(...args);
    let shortcuts = [];
    let apps = /* @__PURE__ */ new Map();
    const icons = /* @__PURE__ */ new Map();
    let sent = /* @__PURE__ */ new Set();
    let media = null;
    let awake = null;
    let hidden = [];
    let running = [];
    let runSent = /* @__PURE__ */ new Set();
    let keys = { app: "", items: [], at: 0 };
    const listKeys = async () => {
      try {
        const read = JSON.parse(await jxa(MENU_SCRIPT, [], 2e4) ?? "{}");
        if (typeof read.app === "string") keys = { app: read.app, items: Array.isArray(read.items) ? read.items : [], at: Date.now() };
      } catch {
      }
      send({ type: "keys", app: keys.app, items: keys.items });
    };
    let clips = [];
    let clipId = 0;
    const listClips = () => send({ type: "clips", items: clips });
    const noteClip = async () => {
      const out = await jxa(CLIP_SCRIPT);
      if (!out?.trim()) return;
      let text2;
      try {
        text2 = JSON.parse(out);
      } catch {
        return;
      }
      if (!text2.trim() || clips[0]?.text === text2) return;
      clips = [{ id: ++clipId, text: text2.slice(0, CLIP_MAX), at: Date.now() }, ...clips.filter((c) => c.text !== text2)].slice(0, CLIPS_KEPT);
      if (watching()) listClips();
    };
    stopAwake = () => awake?.kill("SIGTERM");
    let extras = null;
    let extrasAt = 0;
    const send = (message) => ctx.broadcast(json(message));
    const watching = () => ctx.devices.some((d) => d.connected && d.active);
    const catalog = async () => {
      [shortcuts, apps] = await Promise.all([listShortcuts(), listApps()]);
      const meta = await jxaJson(META_SCRIPT, [...apps.values()]);
      const actions = [
        ...CONTROLS,
        ...shortcuts.map((name) => ({ id: `shortcut:${name}`, label: name.trim(), kind: "shortcut" })),
        ...[...apps].map(([name, path]) => ({
          id: `app:${name}`,
          label: name,
          kind: "app",
          group: categoryOf(meta[path]?.kind ?? null, path),
          used: meta[path]?.used ?? 0
        }))
      ];
      send({ type: "catalog", actions });
      const missing = [...apps.values()].filter((path) => !icons.has(path));
      for (const [path, png] of Object.entries(await jxaJson(ICON_SCRIPT, missing))) icons.set(path, png);
      const due = [...apps].flatMap(([name, path]) => icons.has(path) && !sent.has(path) ? [[`app:${name}`, icons.get(path), path]] : []);
      for (let i = 0; i < due.length; i += ICONS_PER_MESSAGE) {
        const batch = due.slice(i, i + ICONS_PER_MESSAGE);
        send({ type: "icons", icons: Object.fromEntries(batch.map(([id, png]) => [id, png])) });
        batch.forEach(([, , path]) => sent.add(path));
      }
    };
    const fresh = () => {
      sent = /* @__PURE__ */ new Set();
      runSent = /* @__PURE__ */ new Set();
      catalog().then(() => state());
    };
    const state = async (fresh2 = false) => {
      const [{ input: _input, ...now }, more] = await Promise.all([
        readState(),
        fresh2 || !extras || Date.now() - extrasAt > EXTRAS_EVERY_MS ? readExtras(!!awake) : extras
      ]);
      if (more !== extras) [extras, extrasAt] = [more, Date.now()];
      media = now.media;
      send({ type: "state", ...now, ...more, awake: !!awake });
    };
    const perform = async (id) => {
      if (id === "mute") return await osa("set volume output muted (not (output muted of (get volume settings)))") !== null;
      if (id === "vol-up" || id === "vol-down") return step(id === "vol-up" ? 6 : -6);
      if (id === "mic") {
        const { micMuted, input } = await readState();
        const back = Number(await ctx.kv.get("micLevel") ?? 75);
        if (!micMuted) await ctx.kv.set("micLevel", input || 75);
        return await osa(`set volume input volume ${micMuted ? Math.round(back) : 0}`) !== null;
      }
      if (id === "screenshot") {
        const stamp = (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " at ").replaceAll(":", ".");
        const home = Deno.env.get("HOME");
        if (home && await capture(["-x", `${home}/Desktop/Deck ${stamp}.png`])) return true;
        return capture(["-x", "-c"]);
      }
      if (id === "mission") return await run("/usr/bin/open", ["-a", "Mission Control"]) !== null;
      if (id === "bluetooth") return await run("/usr/bin/open", ["x-apple.systempreferences:com.apple.BluetoothSettings"]) !== null;
      if (id === "display-sleep") return await run("/usr/bin/pmset", ["displaysleepnow"]) !== null;
      if (id === "sleep") return await run("/usr/bin/pmset", ["sleepnow"]) !== null;
      if (id === "awake") {
        if (awake) {
          awake.kill("SIGTERM");
          awake = null;
        } else awake = new Deno.Command("/usr/bin/caffeinate", { args: ["-di"], stdout: "null", stderr: "null", stdin: "null" }).spawn();
        return true;
      }
      if (id === "dark") return await osa('tell application "System Events" to tell appearance preferences to set dark mode to not dark mode') !== null;
      if (id === "desktop") {
        if (hidden.length) {
          await jxa(SHOW_SCRIPT, hidden);
          hidden = [];
          return true;
        }
        try {
          hidden = JSON.parse(await jxa(HIDE_SCRIPT) ?? "[]");
          return true;
        } catch {
          return false;
        }
      }
      if (id === "wifi") {
        const now = await readExtras(!!awake);
        if (!wifiDevice || now.wifi === null) return false;
        return await run("/usr/sbin/networksetup", ["-setairportpower", wifiDevice, now.wifi ? "off" : "on"], 15e3) !== null;
      }
      if (id === "battery") return true;
      if (id === "focus") return shortcuts.includes(FOCUS_SHORTCUT) && await run("/usr/bin/shortcuts", ["run", FOCUS_SHORTCUT], 3e4) !== null;
      if (id === "screensaver") return await run("/usr/bin/open", ["-a", "ScreenSaverEngine"]) !== null;
      if (id === "quit") return !!(await jxa(QUIT_SCRIPT))?.trim();
      if (id === "bright-up" || id === "bright-down") return await osa(`tell application "System Events" to key code ${id === "bright-up" ? 144 : 145}`) !== null;
      if (id === "trash") return await osa('tell application "Finder" to empty trash') !== null;
      if (id.startsWith("shortcut:")) {
        const name = id.slice("shortcut:".length);
        return shortcuts.includes(name) && await run("/usr/bin/shortcuts", ["run", name], 12e4) !== null;
      }
      if (id.startsWith("app:")) {
        const name = id.slice("app:".length);
        return apps.has(name) && await run("/usr/bin/open", ["-a", name]) !== null;
      }
      return false;
    };
    const step = async (delta) => {
      const { volume } = await readState();
      const next = Math.max(0, Math.min(100, Math.round(volume + delta)));
      return await osa(`set volume output volume ${next}`) !== null;
    };
    ctx.on("device", (event) => {
      if (event.type === "connected" || event.type === "active") fresh();
    });
    ctx.on("message", (_device, message) => {
      const m = asJson(message);
      if (!m || typeof m !== "object") return;
      if (m.type === "hello") fresh();
      else if (m.type === "run" && typeof m.id === "string") {
        perform(m.id).catch(() => false).then((ok) => {
          ctx.log.info(`ran ${m.id}: ${ok ? "ok" : "failed"}`);
          send({ type: "result", id: m.id, ok });
          state(true);
        });
      } else if (m.type === "volume" && typeof m.delta === "number" && Number.isFinite(m.delta)) {
        step(Math.max(-20, Math.min(20, m.delta))).then(() => state());
      } else if (m.type === "set-volume" && typeof m.level === "number" && Number.isFinite(m.level)) {
        const level = Math.max(0, Math.min(100, Math.round(m.level)));
        osa(`set volume output volume ${level}`).then(() => state());
      } else if (m.type === "keys") {
        if (keys.app && Date.now() - keys.at < KEYS_EVERY_MS) send({ type: "keys", app: keys.app, items: keys.items });
        listKeys();
      } else if (m.type === "press" && typeof m.app === "string" && m.app === keys.app && keys.items.some((k) => k.menu === m.menu && k.title === m.title)) {
        jxa(PRESS_SCRIPT, [m.app, m.menu, m.title]).then((out) => {
          const id = `key:${m.menu}/${m.title}`;
          send({ type: "result", id, ok: out?.trim() === "ok" });
        });
      } else if (m.type === "clips") listClips();
      else if (m.type === "clear-clips") {
        clips = [];
        listClips();
      } else if (m.type === "copy" && typeof m.id === "number") {
        const found = clips.find((c) => c.id === m.id);
        if (found) jxa(COPY_SCRIPT, [found.text]).then(() => noteClip()).then(() => state());
      } else if (m.type === "running") {
        jxa(RUNNING_SCRIPT).then(async (out) => {
          try {
            running = JSON.parse(out ?? "[]");
          } catch {
            running = [];
          }
          send({ type: "running", apps: running });
          const missing = running.map((a) => a.path).filter((path) => !icons.has(path));
          for (const [path, png] of Object.entries(await jxaJson(ICON_SCRIPT, missing))) icons.set(path, png);
          const due = running.filter((a) => icons.has(a.path) && !runSent.has(a.path));
          if (due.length) send({ type: "icons", icons: Object.fromEntries(due.map((a) => [`run:${a.path}`, icons.get(a.path)])) });
          due.forEach((a) => runSent.add(a.path));
        });
      } else if (m.type === "quit-app" && typeof m.path === "string" && running.some((a) => a.path === m.path)) {
        jxa(QUIT_APP_SCRIPT, [m.path]).then((out) => {
          send({ type: "result", id: `quit:${m.path}`, ok: out?.trim() === "ok" });
          setTimeout(() => jxa(RUNNING_SCRIPT).then((next) => {
            try {
              running = JSON.parse(next ?? "[]");
              send({ type: "running", apps: running });
            } catch {
            }
          }), 800);
        });
      } else if (m.type === "switch" && typeof m.path === "string" && running.some((a) => a.path === m.path)) {
        run("/usr/bin/open", [m.path]).then(() => setTimeout(() => state(), 300));
      } else if (m.type === "media" && MEDIA_COMMANDS.includes(m.command) && media && MEDIA_APPS.includes(media.app)) {
        jxa(MEDIA_SCRIPT, [media.app, m.command]).then(() => setTimeout(state, 300));
      }
    });
    timers = [
      setInterval(() => watching() && catalog(), CATALOG_EVERY_MS),
      setInterval(() => watching() && state(), STATE_EVERY_MS),
      // the clipboard is watched all the time the extension runs, so the history has what was copied while the deck was away
      setInterval(noteClip, CLIP_EVERY_MS)
    ];
  },
  stop() {
    timers.forEach(clearInterval);
    stopAwake();
  }
});
