// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder2 = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder2.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder2.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run2) {
    try {
      return run2();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// src/protocol/types.ts
var PROTOCOL_VERSION = 1;

// extension/collectors/macos.ts
import { cpus } from "node:os";

// extension/run.ts
var decoder = new TextDecoder();
async function run(binary2, args, timeoutMs = 4e3) {
  try {
    const { success, stdout } = await new Deno.Command(binary2, {
      args,
      stdout: "piped",
      stderr: "null",
      stdin: "null",
      signal: AbortSignal.timeout(timeoutMs),
      // a fixed locale keeps decimal points and column names the same on every machine
      env: { LC_ALL: "C" }
    }).output();
    return success ? decoder.decode(stdout) : null;
  } catch {
    return null;
  }
}
async function runJson(binary2, args, timeoutMs = 8e3) {
  const text2 = await run(binary2, args, timeoutMs);
  if (!text2) return null;
  try {
    return JSON.parse(text2);
  } catch {
    return null;
  }
}
function after(text2, label) {
  const at = text2.indexOf(label);
  if (at === -1) return void 0;
  const match = /-?\d+(\.\d+)?/.exec(text2.slice(at + label.length));
  return match ? Number(match[0]) : void 0;
}
var round = (v, places = 1) => Math.round(v * 10 ** places) / 10 ** places;
var GB = 1024 ** 3;

// extension/collectors/macos.ts
var BIN = {
  vmStat: "/usr/bin/vm_stat",
  sysctl: "/usr/sbin/sysctl",
  ioreg: "/usr/sbin/ioreg",
  netstat: "/usr/sbin/netstat",
  ps: "/bin/ps",
  pmset: "/usr/bin/pmset",
  df: "/bin/df",
  ping: "/sbin/ping",
  route: "/sbin/route",
  profiler: "/usr/sbin/system_profiler",
  swVers: "/usr/bin/sw_vers",
  scutil: "/usr/sbin/scutil",
  ifconfig: "/sbin/ifconfig",
  networksetup: "/usr/sbin/networksetup"
};
var PING_HOST = "1.1.1.1";
var PROCESS_COUNT = 25;
function ticks() {
  return cpus().map((c) => {
    const t = c.times;
    return { idle: t.idle, total: t.user + t.nice + t.sys + t.idle + t.irq };
  });
}
function busy(prev, now) {
  const total = now.total - prev.total;
  return total > 0 ? Math.min(100, Math.max(0, (1 - (now.idle - prev.idle) / total) * 100)) : 0;
}
function memory(text2, totalBytes) {
  const page = after(text2, "page size of") ?? 16384;
  const pages = (label) => (after(text2, label) ?? 0) * page;
  const app = pages("Anonymous pages:") - pages("Pages purgeable:");
  const used = app + pages("Pages wired down:") + pages("Pages occupied by compressor:");
  const cached = pages("File-backed pages:") + pages("Pages purgeable:");
  return { used: used / GB, cached: cached / GB, available: (totalBytes - used) / GB, usage: used / totalBytes * 100 };
}
function swap(text2) {
  const mb = (label) => {
    const m = new RegExp(`${label} = ([\\d.]+)([MG])`).exec(text2);
    if (!m) return void 0;
    return Number(m[1]) / (m[2] === "G" ? 1 : 1024);
  };
  return { swapTotal: mb("total"), swapUsed: mb("used") };
}
function ioregNumber(text2, key) {
  const m = new RegExp(`"${key.replace(/[()%]/g, (c) => `\\${c}`)}"=(\\d+)`).exec(text2);
  return m ? Number(m[1]) : void 0;
}
var rssiPercent = (dbm) => Math.round(Math.min(100, Math.max(0, (dbm + 90) / 60 * 100)));
function macosCollector() {
  let lastTicks = ticks();
  let lastNet = null;
  let lastDisk = null;
  let iface = null;
  let totalBytes = 0;
  let internalModel;
  let caps = {
    cpu: true,
    cpuTemperature: false,
    gpu: false,
    gpuTemperature: false,
    memory: true,
    storage: true,
    network: true,
    battery: false,
    processes: true,
    displays: false
  };
  async function defaultInterface() {
    const out = await run(BIN.route, ["-n", "get", "default"]);
    const m = out && /interface:\s*(\S+)/.exec(out);
    iface = m ? m[1] : null;
  }
  return {
    capabilities: () => caps,
    async fast() {
      const now = Date.now();
      const nowTicks = ticks();
      const perCore = nowTicks.map((t, i) => lastTicks[i] ? busy(lastTicks[i], t) : 0);
      const all = busy(
        lastTicks.reduce((a, t) => ({ idle: a.idle + t.idle, total: a.total + t.total }), { idle: 0, total: 0 }),
        nowTicks.reduce((a, t) => ({ idle: a.idle + t.idle, total: a.total + t.total }), { idle: 0, total: 0 })
      );
      lastTicks = nowTicks;
      const [vm, swapText, gpuText, netText] = await Promise.all([
        run(BIN.vmStat, []),
        run(BIN.sysctl, ["-n", "vm.swapusage"]),
        run(BIN.ioreg, ["-r", "-d", "1", "-w0", "-c", "IOAccelerator"]),
        iface ? run(BIN.netstat, ["-ibn", "-I", iface]) : Promise.resolve(null)
      ]);
      const section = {
        cpu: { usage: round(all), perCoreUsage: perCore.map((v) => Math.round(v)), load: Deno.loadavg().map((v) => round(v, 2)) },
        system: { uptime: Math.round(Deno.osUptime()) }
      };
      const speed = cpus()[0]?.speed ?? 0;
      if (Deno.build.arch === "x86_64" && speed > 100 && section.cpu) section.cpu.frequency = speed;
      if (vm && totalBytes > 0) {
        const m = memory(vm, totalBytes);
        section.memory = { total: round(totalBytes / GB), used: round(m.used), available: round(m.available), cached: round(m.cached), usage: round(m.usage), ...swapText ? swap(swapText) : {} };
      }
      const gpuUse = gpuText ? ioregNumber(gpuText, "Device Utilization %") : void 0;
      if (gpuUse !== void 0) {
        const inUse = ioregNumber(gpuText, "In use system memory");
        section.gpu = { usage: gpuUse, ...inUse !== void 0 ? { memoryUsed: round(inUse / GB) } : {} };
      }
      const row = netText?.split("\n").find((l) => l.startsWith(`${iface} `) && l.includes("<Link#"));
      if (row) {
        const cols = row.trim().split(/\s+/);
        const rx = Number(cols[6]);
        const tx = Number(cols[9]);
        if (lastNet && now > lastNet.at && rx >= lastNet.rx && tx >= lastNet.tx) {
          const secs = (now - lastNet.at) / 1e3;
          section.network = { download: round((rx - lastNet.rx) * 8 / secs / 1e6, 2), upload: round((tx - lastNet.tx) * 8 / secs / 1e6, 2), connected: true };
        }
        lastNet = { at: now, rx, tx };
      }
      return section;
    },
    async medium() {
      await defaultInterface();
      const now = Date.now();
      const [psText, batt, dfText, pingText, diskText] = await Promise.all([
        run(BIN.ps, ["-Aceo", "pid=,pcpu=,rss=,comm=", "-r"]),
        run(BIN.pmset, ["-g", "batt"]),
        run(BIN.df, ["-k", "-P"]),
        run(BIN.ping, ["-c", "1", "-t", "2", PING_HOST], 4e3),
        run(BIN.ioreg, ["-c", "IOBlockStorageDriver", "-r", "-w0", "-d", "1"])
      ]);
      const section = {};
      if (psText) {
        const procs = [];
        for (const line of psText.split("\n")) {
          const m = /^\s*(\d+)\s+([\d.]+)\s+(\d+)\s+(.+)$/.exec(line);
          if (m) procs.push({ pid: Number(m[1]), cpu: Number(m[2]), memory: round(Number(m[3]) / 1024 / 1024, 2), name: m[4].trim() });
          if (procs.length >= PROCESS_COUNT) break;
        }
        section.processes = procs;
      }
      const battery = batt && /(\d+)%;\s*([a-z ]+);/i.exec(batt);
      if (battery) {
        section.battery = { percentage: Number(battery[1]), charging: battery[2].trim() === "charging" || batt.includes("'AC Power'") };
        caps = { ...caps, battery: true };
      }
      if (dfText) {
        const drives = [];
        let read;
        let write;
        if (diskText) {
          const sum = (key) => [...diskText.matchAll(new RegExp(`"Bytes \\(${key}\\)"=(\\d+)`, "g"))].reduce((a, m) => a + Number(m[1]), 0);
          const r = sum("Read");
          const w = sum("Write");
          if (lastDisk && now > lastDisk.at && r >= lastDisk.read && w >= lastDisk.write) {
            const secs = (now - lastDisk.at) / 1e3;
            read = round((r - lastDisk.read) / secs / 1e6);
            write = round((w - lastDisk.write) / secs / 1e6);
          }
          lastDisk = { at: now, read: r, write: w };
        }
        for (const line of dfText.split("\n").slice(1)) {
          const cols = line.trim().split(/\s+/);
          if (cols.length < 6) continue;
          const mount = cols.slice(5).join(" ");
          const isData = mount === "/System/Volumes/Data";
          const isExternal = mount.startsWith("/Volumes/") && !mount.includes("TimeMachine");
          if (!isData && !isExternal) continue;
          const total = Number(cols[1]) / 1024 / 1024;
          const free = Number(cols[3]) / 1024 / 1024;
          const used = total - free;
          drives.push({
            id: cols[0],
            name: isData ? "Macintosh HD" : mount.slice("/Volumes/".length),
            ...isData && internalModel ? { model: internalModel } : {},
            total: round(total),
            used: round(used),
            free: round(free),
            usage: round(used / total * 100),
            // the block counters are for the internal drive; an external one gets its own figures later
            ...isData && read !== void 0 ? { readSpeed: read, writeSpeed: write } : {}
          });
        }
        section.storage = drives;
      }
      const ping = pingText ? /time=([\d.]+)/.exec(pingText) : null;
      section.network = { ...ping ? { ping: round(Number(ping[1])) } : {}, connected: iface !== null };
      return section;
    },
    async slow() {
      if (!iface) await defaultInterface();
      const [brand, physical, logical, memsize, version, computerName, ports, displays, airport, power, nvme, media] = await Promise.all([
        run(BIN.sysctl, ["-n", "machdep.cpu.brand_string"]),
        run(BIN.sysctl, ["-n", "hw.physicalcpu"]),
        run(BIN.sysctl, ["-n", "hw.logicalcpu"]),
        run(BIN.sysctl, ["-n", "hw.memsize"]),
        run(BIN.swVers, ["-productVersion"]),
        run(BIN.scutil, ["--get", "ComputerName"]),
        run(BIN.networksetup, ["-listallhardwareports"]),
        runJson(BIN.profiler, ["SPDisplaysDataType", "-json"]),
        runJson(BIN.profiler, ["SPAirPortDataType", "-json"]),
        runJson(BIN.profiler, ["SPPowerDataType", "-json"]),
        runJson(BIN.profiler, ["SPNVMeDataType", "-json"]),
        iface ? run(BIN.ifconfig, [iface]) : Promise.resolve(null)
      ]);
      totalBytes = Number(memsize) || totalBytes;
      const section = {
        device: { name: computerName?.trim() || Deno.hostname(), version: version ? `macOS ${version.trim()}` : "macOS", architecture: Deno.build.arch === "aarch64" ? "arm64" : Deno.build.arch },
        system: { hostname: Deno.hostname(), os: version ? `macOS ${version.trim()}` : "macOS", kernel: `Darwin ${Deno.osRelease()}`, uptime: Math.round(Deno.osUptime()) },
        cpu: { name: brand?.trim() || cpus()[0]?.model, cores: Number(physical) || void 0, threads: Number(logical) || void 0 }
      };
      const card = displays?.SPDisplaysDataType?.[0];
      if (card) {
        const name = card.sppci_model ? `${card.sppci_model} GPU${card.sppci_cores ? ` (${card.sppci_cores}-core)` : ""}` : void 0;
        section.gpu = { name };
        caps = { ...caps, gpu: true };
        const list = (card.spdisplays_ndrvs ?? []).map((d) => {
          const px = /(\d+)\s*x\s*(\d+)/.exec(d._spdisplays_pixels ?? d._spdisplays_resolution ?? "");
          const hz = /@\s*([\d.]+)Hz/.exec(d._spdisplays_resolution ?? "");
          return { name: d._name, width: px ? Number(px[1]) : void 0, height: px ? Number(px[2]) : void 0, refreshRate: hz ? Math.round(Number(hz[1])) : void 0 };
        });
        if (list.length) {
          section.displays = list;
          caps = { ...caps, displays: true };
        }
      }
      const portName = ports && iface ? new RegExp(`Hardware Port: (.+)\\nDevice: ${iface}\\b`).exec(ports)?.[1] : void 0;
      const addresses = Deno.networkInterfaces().filter((n) => n.name === iface);
      section.network = {
        interface: portName ? `${portName} (${iface})` : iface ?? void 0,
        ip: addresses.find((a) => a.family === "IPv4")?.address,
        ipv6: addresses.find((a) => a.family === "IPv6" && !a.address.startsWith("fe80"))?.address
      };
      const wifi = airport?.SPAirPortDataType?.[0]?.spairport_airport_interfaces?.find((i) => i._name === iface)?.spairport_current_network_information;
      if (wifi?.spairport_network_rate) section.network.linkSpeed = wifi.spairport_network_rate;
      const rssi = wifi?.spairport_signal_noise ? /(-\d+)\s*dBm/.exec(wifi.spairport_signal_noise) : null;
      if (rssi) section.network.signal = rssiPercent(Number(rssi[1]));
      const wired = media ? /media:.*?(\d+)base/.exec(media) : null;
      if (!section.network.linkSpeed && wired) section.network.linkSpeed = Number(wired[1]);
      const health = power?.SPPowerDataType?.find((p) => p.sppower_battery_health_info)?.sppower_battery_health_info;
      if (health) {
        section.battery = {
          cycleCount: health.sppower_battery_cycle_count,
          health: health.sppower_battery_health_maximum_capacity ? Number.parseInt(health.sppower_battery_health_maximum_capacity, 10) : void 0
        };
      }
      internalModel = nvme?.SPNVMeDataType?.flatMap((c) => c._items ?? [])[0]?.device_model ?? internalModel;
      return section;
    }
  };
}

// extension/main.ts
var MIN_INTERVAL = 1e3;
var MAX_INTERVAL = 5e3;
var MEDIUM_EVERY = 5;
var SLOW_EVERY = 30;
function collectorFor(os) {
  if (os === "darwin") return { platform: "macos", collector: macosCollector() };
  return null;
}
function merge(...parts) {
  const out = {};
  for (const part of parts) {
    for (const [key, value] of Object.entries(part)) {
      if (value === void 0) continue;
      const prev = out[key];
      out[key] = value && typeof value === "object" && !Array.isArray(value) && prev && typeof prev === "object" && !Array.isArray(prev) ? { ...prev, ...value } : value;
    }
  }
  return out;
}
var timer;
defineExtension({
  start(ctx) {
    const found = collectorFor(Deno.build.os);
    let interval = MIN_INTERVAL;
    let deviceId = null;
    let slow = {};
    let medium = {};
    let tick = 0;
    let busy2 = false;
    const watching = () => ctx.devices.some((d) => d.connected && d.active);
    const hello = () => ctx.broadcast(
      json({
        type: "hello",
        role: "agent",
        protocol: PROTOCOL_VERSION,
        ...found && deviceId ? { devices: [{ id: deviceId, name: String(slow.device?.name ?? Deno.hostname()), platform: found.platform, online: true }] } : {}
      })
    );
    const sendCapabilities = () => {
      if (found && deviceId) ctx.broadcast(json({ type: "capabilities", deviceId, capabilities: found.collector.capabilities() }));
    };
    ctx.on("device", (event) => {
      if (event.type === "disconnected") return;
      hello();
      sendCapabilities();
    });
    ctx.on("message", (_device, message) => {
      const payload = asJson(message);
      if (payload?.type !== "hello") return;
      if (typeof payload.interval === "number" && Number.isFinite(payload.interval)) {
        interval = Math.min(MAX_INTERVAL, Math.max(MIN_INTERVAL, Math.round(payload.interval)));
      }
      hello();
      sendCapabilities();
    });
    if (!found) {
      ctx.log.warn(`no collector for ${Deno.build.os} yet`);
      ctx.broadcast(json({ type: "error", message: `This computer (${Deno.build.os}) is not supported yet` }));
      return;
    }
    const { platform, collector } = found;
    const frame = async () => {
      if (!busy2 && deviceId && watching()) {
        busy2 = true;
        try {
          if (tick % SLOW_EVERY === 0) slow = await collector.slow();
          if (tick % MEDIUM_EVERY === 0) medium = await collector.medium();
          const fast = await collector.fast();
          const now = Date.now();
          const merged = merge(slow, medium, fast);
          const data = {
            ...merged,
            device: { online: true, ...merged.device, id: deviceId, name: String(merged.device?.name ?? Deno.hostname()), platform },
            system: { ...merged.system, timestamp: now }
          };
          const caps = collector.capabilities();
          if (!caps.gpu) data.gpu = null;
          if (!caps.battery) data.battery = null;
          if (tick === 0) sendCapabilities();
          ctx.broadcast(json({ type: "telemetry", timestamp: now, deviceId, data }));
          tick++;
        } catch (err) {
          ctx.log.warn("collection failed", String(err));
        } finally {
          busy2 = false;
        }
      }
      timer = setTimeout(frame, interval);
    };
    ctx.kv.get("deviceId").then(async (stored) => {
      deviceId = stored ?? `${platform}-${crypto.randomUUID().slice(0, 8)}`;
      if (!stored) await ctx.kv.set("deviceId", deviceId);
      ctx.log.info(`agent up on ${platform} as ${deviceId}`);
      hello();
      void frame();
    }).catch((err) => ctx.log.error("could not read the device id", String(err)));
  },
  stop() {
    clearTimeout(timer);
  }
});
