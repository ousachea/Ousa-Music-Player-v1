// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder2 = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder2.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder2.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run2) {
    try {
      return run2();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// src/protocol/types.ts
var PROTOCOL_VERSION = 1;

// extension/collectors/linux.ts
import { cpus as cpus2 } from "node:os";

// extension/run.ts
var decoder = new TextDecoder();
async function run(binary2, args, timeoutMs = 4e3) {
  try {
    const { success, stdout } = await new Deno.Command(binary2, {
      args,
      stdout: "piped",
      stderr: "null",
      stdin: "null",
      signal: AbortSignal.timeout(timeoutMs),
      // a fixed locale keeps decimal points and column names the same on every machine
      env: { LC_ALL: "C" }
    }).output();
    return success ? decoder.decode(stdout) : null;
  } catch {
    return null;
  }
}
async function runJson(binary2, args, timeoutMs = 8e3) {
  const text2 = await run(binary2, args, timeoutMs);
  if (!text2) return null;
  try {
    return JSON.parse(text2);
  } catch {
    return null;
  }
}
function after(text2, label) {
  const at = text2.indexOf(label);
  if (at === -1) return void 0;
  const match = /-?\d+(\.\d+)?/.exec(text2.slice(at + label.length));
  return match ? Number(match[0]) : void 0;
}
var round = (v, places = 1) => Math.round(v * 10 ** places) / 10 ** places;
var GB = 1024 ** 3;

// extension/collectors/linux-parse.ts
var KB_PER_GB = 1024 * 1024;
function parseMeminfo(text2) {
  const kb = (key) => {
    const m = new RegExp(`^${key}:\\s+(\\d+)`, "m").exec(text2);
    return m ? Number(m[1]) : void 0;
  };
  const total = kb("MemTotal");
  const available = kb("MemAvailable") ?? kb("MemFree");
  if (total === void 0 || available === void 0) return null;
  const cached = (kb("Cached") ?? 0) + (kb("Buffers") ?? 0) + (kb("SReclaimable") ?? 0);
  const swapTotal = kb("SwapTotal");
  const swapFree = kb("SwapFree");
  const used = total - available;
  return {
    total: round(total / KB_PER_GB),
    used: round(used / KB_PER_GB),
    available: round(available / KB_PER_GB),
    cached: round(cached / KB_PER_GB),
    usage: round(used / total * 100),
    ...swapTotal !== void 0 ? { swapTotal: round(swapTotal / KB_PER_GB) } : {},
    ...swapTotal !== void 0 && swapFree !== void 0 ? { swapUsed: round((swapTotal - swapFree) / KB_PER_GB) } : {}
  };
}
function parseDefaultRoute(text2) {
  let best = null;
  for (const line of text2.split("\n").slice(1)) {
    const f = line.trim().split(/\s+/);
    if (f.length < 8 || f[1] !== "00000000" || f[7] !== "00000000") continue;
    const metric = Number(f[6]);
    if (!best || metric < best.metric) best = { iface: f[0], metric };
  }
  return best?.iface ?? null;
}
function parseTotalJiffies(text2) {
  const line = text2.split("\n").find((l) => l.startsWith("cpu "));
  if (!line) return null;
  return line.trim().split(/\s+/).slice(1, 9).reduce((a, v) => a + Number(v), 0);
}
function parsePidStat(text2) {
  const open = text2.indexOf("(");
  const close = text2.lastIndexOf(")");
  if (open === -1 || close < open) return null;
  const rest = text2.slice(close + 2).split(" ");
  const utime = Number(rest[11]);
  const stime = Number(rest[12]);
  const rss = Number(rest[21]);
  if (!Number.isFinite(utime) || !Number.isFinite(stime)) return null;
  return { name: text2.slice(open + 1, close), jiffies: utime + stime, rssPages: Number.isFinite(rss) ? rss : 0 };
}
var REAL_FS = /* @__PURE__ */ new Set(["ext2", "ext3", "ext4", "xfs", "btrfs", "f2fs", "vfat", "exfat", "ntfs", "ntfs3", "zfs", "bcachefs", "jfs", "reiserfs"]);
function parseMounts(text2) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const line of text2.split("\n")) {
    const [device, rawMount, fstype] = line.split(" ");
    if (!device || !rawMount || !REAL_FS.has(fstype)) continue;
    const mount = rawMount.replace(/\\040/g, " ");
    if (mount.startsWith("/boot") || mount.startsWith("/snap") || mount.startsWith("/var/lib/docker")) continue;
    if (seen.has(device)) continue;
    seen.add(device);
    out.push({ device, mount, fstype });
  }
  return out;
}
function parseDf(text2) {
  const out = /* @__PURE__ */ new Map();
  for (const line of text2.split("\n").slice(1)) {
    const f = line.trim().split(/\s+/);
    if (f.length < 6) continue;
    const total = Number(f[1]);
    const used = Number(f[2]);
    const free = Number(f[3]);
    if (!Number.isFinite(total) || total <= 0) continue;
    out.set(f.slice(5).join(" "), { total: total / KB_PER_GB, used: used / KB_PER_GB, free: free / KB_PER_GB });
  }
  return out;
}
function parentDisk(device) {
  const name = device.replace(/^\/dev\//, "");
  if (/^(nvme\d+n\d+|mmcblk\d+)p\d+$/.test(name)) return name.replace(/p\d+$/, "");
  return name.replace(/\d+$/, "");
}
function parseDiskstats(text2, disk) {
  for (const line of text2.split("\n")) {
    const f = line.trim().split(/\s+/);
    if (f[2] === disk) return { read: Number(f[5]) * 512, write: Number(f[9]) * 512 };
  }
  return null;
}
function parseOsRelease(text2) {
  const m = /^PRETTY_NAME="?([^"\n]+)"?/m.exec(text2);
  return m?.[1];
}
function parseCpuinfo(text2) {
  const model = /^(model name|Model|Hardware)\s*:\s*(.+)$/m.exec(text2)?.[2]?.trim();
  const mhz = [...text2.matchAll(/^cpu MHz\s*:\s*([\d.]+)/gm)].map((m) => Number(m[1]));
  const cores = /* @__PURE__ */ new Set();
  let physical = "0";
  for (const line of text2.split("\n")) {
    if (line.startsWith("physical id")) physical = line.split(":")[1].trim();
    if (line.startsWith("core id")) cores.add(`${physical}:${line.split(":")[1].trim()}`);
  }
  return {
    model,
    cores: cores.size || void 0,
    frequency: mhz.length ? Math.round(mhz.reduce((a, v) => a + v, 0) / mhz.length) : void 0
  };
}
function parseWireless(text2, iface) {
  const line = text2.split("\n").find((l) => l.trim().startsWith(`${iface}:`));
  if (!line) return void 0;
  const f = line.trim().split(/\s+/);
  const level = Number.parseFloat(f[3]);
  return Number.isFinite(level) && level < 0 ? level : void 0;
}
function parsePing(text2) {
  const m = /time[=<]([\d.]+)\s*ms/.exec(text2);
  return m ? round(Number(m[1])) : void 0;
}
var CPU_SENSORS = ["k10temp", "zenpower", "coretemp", "cpu_thermal", "soc_thermal", "acpitz"];

// extension/collectors/shared.ts
import { cpus } from "node:os";
function readTicks() {
  return cpus().map((c) => {
    const t = c.times;
    return { idle: t.idle, total: t.user + t.nice + t.sys + t.idle + t.irq };
  });
}
function busy(prev, now) {
  const total = now.total - prev.total;
  return total > 0 ? Math.min(100, Math.max(0, (1 - (now.idle - prev.idle) / total) * 100)) : 0;
}
var sum = (list2) => list2.reduce((a, t) => ({ idle: a.idle + t.idle, total: a.total + t.total }), { idle: 0, total: 0 });
function cpuMeter() {
  let last = readTicks();
  return () => {
    const now = readTicks();
    const perCore = now.map((t, i) => last[i] ? Math.round(busy(last[i], t)) : 0);
    const usage = round(busy(sum(last), sum(now)));
    last = now;
    return { usage, perCoreUsage: perCore };
  };
}
function rateMeter() {
  let last = null;
  return (values, at = Date.now()) => {
    const prev = last;
    last = { at, values };
    if (!prev || at <= prev.at || values.length !== prev.values.length) return null;
    if (values.some((v, i) => v < prev.values[i])) return null;
    const secs = (at - prev.at) / 1e3;
    return values.map((v, i) => (v - prev.values[i]) / secs);
  };
}
var mbps = (bytesPerSec) => round(bytesPerSec * 8 / 1e6, 2);
var rssiPercent = (dbm) => Math.round(Math.min(100, Math.max(0, (dbm + 90) / 60 * 100)));
var NVIDIA_QUERY = "name,utilization.gpu,temperature.gpu,memory.used,memory.total,clocks.gr,power.draw,fan.speed";
function parseNvidiaSmi(text2) {
  const line = text2.split(/\r?\n/).find((l) => l.trim());
  if (!line) return null;
  const f = line.split(",").map((s) => s.trim());
  if (f.length < 8 || !f[0]) return null;
  const n = (s) => {
    const v = Number.parseFloat(s);
    return Number.isFinite(v) ? v : void 0;
  };
  const mib = (s) => {
    const v = n(s);
    return v === void 0 ? void 0 : round(v / 1024);
  };
  const gpu = {
    name: f[0],
    usage: n(f[1]),
    temperature: n(f[2]),
    memoryUsed: mib(f[3]),
    memoryTotal: mib(f[4]),
    frequency: n(f[5]),
    power: n(f[6]) === void 0 ? void 0 : Math.round(n(f[6])),
    fan: n(f[7])
  };
  for (const k of Object.keys(gpu)) if (gpu[k] === void 0) delete gpu[k];
  return gpu;
}

// extension/collectors/linux.ts
var PING_HOST = "1.1.1.1";
var PROCESS_COUNT = 25;
var PAGE_BYTES = 4096;
var GB2 = 1024 ** 3;
async function read(path) {
  try {
    return await Deno.readTextFile(path);
  } catch {
    return null;
  }
}
async function readNumber(path) {
  const text2 = await read(path);
  const v = text2 === null ? NaN : Number(text2.trim());
  return Number.isFinite(v) ? v : void 0;
}
async function list(path) {
  const out = [];
  try {
    for await (const entry of Deno.readDir(path)) out.push(entry.name);
  } catch {
  }
  return out.sort();
}
async function hwmons() {
  const out = /* @__PURE__ */ new Map();
  for (const dir of await list("/sys/class/hwmon")) {
    const name = (await read(`/sys/class/hwmon/${dir}/name`))?.trim();
    if (name && !out.has(name)) out.set(name, `/sys/class/hwmon/${dir}`);
  }
  return out;
}
function linuxCollector() {
  const cpu = cpuMeter();
  const net = rateMeter();
  const disk = rateMeter();
  let iface = null;
  let sensors = /* @__PURE__ */ new Map();
  let nvidia = false;
  let amd = null;
  let rootDisk = null;
  let lastProcs = /* @__PURE__ */ new Map();
  let lastJiffies = null;
  let caps = {
    cpu: true,
    cpuTemperature: false,
    gpu: false,
    gpuTemperature: false,
    memory: true,
    storage: true,
    network: true,
    battery: false,
    processes: true,
    displays: false
  };
  async function cpuTemperature() {
    for (const name of CPU_SENSORS) {
      const dir = sensors.get(name);
      if (!dir) continue;
      const milli = await readNumber(`${dir}/temp1_input`);
      if (milli !== void 0) return round(milli / 1e3);
    }
    for (const zone of await list("/sys/class/thermal")) {
      if (!zone.startsWith("thermal_zone")) continue;
      const type = (await read(`/sys/class/thermal/${zone}/type`))?.trim() ?? "";
      if (!/x86_pkg_temp|cpu|soc/i.test(type)) continue;
      const milli = await readNumber(`/sys/class/thermal/${zone}/temp`);
      if (milli !== void 0) return round(milli / 1e3);
    }
    return void 0;
  }
  async function gpu() {
    if (nvidia) return parseNvidiaSmi(await run("nvidia-smi", [`--query-gpu=${NVIDIA_QUERY}`, "--format=csv,noheader,nounits"]) ?? "");
    if (!amd) return null;
    const usage = await readNumber(`${amd.base}/gpu_busy_percent`);
    const used = await readNumber(`${amd.base}/mem_info_vram_used`);
    const total = await readNumber(`${amd.base}/mem_info_vram_total`);
    const temp = amd.hwmon ? await readNumber(`${amd.hwmon}/temp1_input`) : void 0;
    const power = amd.hwmon ? await readNumber(`${amd.hwmon}/power1_average`) : void 0;
    return {
      ...usage !== void 0 ? { usage } : {},
      ...used !== void 0 ? { memoryUsed: round(used / GB2) } : {},
      ...total !== void 0 ? { memoryTotal: round(total / GB2) } : {},
      ...temp !== void 0 ? { temperature: round(temp / 1e3) } : {},
      // microwatts
      ...power !== void 0 ? { power: Math.round(power / 1e6) } : {}
    };
  }
  return {
    capabilities: () => caps,
    async fast() {
      const [mem, loadavg, info, rx, tx, temp, card] = await Promise.all([
        read("/proc/meminfo"),
        read("/proc/loadavg"),
        read("/proc/cpuinfo"),
        iface ? readNumber(`/sys/class/net/${iface}/statistics/rx_bytes`) : Promise.resolve(void 0),
        iface ? readNumber(`/sys/class/net/${iface}/statistics/tx_bytes`) : Promise.resolve(void 0),
        cpuTemperature(),
        gpu()
      ]);
      const { usage, perCoreUsage } = cpu();
      const section = {
        cpu: {
          usage,
          perCoreUsage,
          ...loadavg ? { load: loadavg.split(" ").slice(0, 3).map((v) => round(Number(v), 2)) } : {},
          ...temp !== void 0 ? { temperature: temp } : {},
          ...info && parseCpuinfo(info).frequency ? { frequency: parseCpuinfo(info).frequency } : {}
        },
        system: { uptime: Math.round(Deno.osUptime()) }
      };
      if (temp !== void 0) caps = { ...caps, cpuTemperature: true };
      const m = mem ? parseMeminfo(mem) : null;
      if (m) section.memory = m;
      if (card) section.gpu = card;
      if (rx !== void 0 && tx !== void 0) {
        const rate = net([rx, tx]);
        if (rate) section.network = { download: mbps(rate[0]), upload: mbps(rate[1]), connected: true };
      }
      return section;
    },
    async medium() {
      const [routes, mounts, dfText, pingText, diskstats, stat, pids] = await Promise.all([
        read("/proc/net/route"),
        read("/proc/mounts"),
        run("df", ["-kP"]),
        run("ping", ["-c", "1", "-W", "2", PING_HOST], 4e3),
        read("/proc/diskstats"),
        read("/proc/stat"),
        list("/proc")
      ]);
      iface = routes ? parseDefaultRoute(routes) : iface;
      const section = {};
      const jiffies = stat ? parseTotalJiffies(stat) : null;
      const now = /* @__PURE__ */ new Map();
      const rows = [];
      await Promise.all(
        pids.filter((p) => /^\d+$/.test(p)).map(async (p) => {
          const s = await read(`/proc/${p}/stat`);
          const parsed = s ? parsePidStat(s) : null;
          if (!parsed) return;
          const pid = Number(p);
          now.set(pid, parsed.jiffies);
          const before = lastProcs.get(pid);
          rows.push({ pid, name: parsed.name, delta: before === void 0 ? 0 : parsed.jiffies - before, rss: parsed.rssPages });
        })
      );
      if (jiffies !== null && lastJiffies !== null && jiffies > lastJiffies) {
        const span = (jiffies - lastJiffies) / cpus2().length;
        section.processes = rows.sort((a, b) => b.delta - a.delta || b.rss - a.rss).slice(0, PROCESS_COUNT).map((r) => ({ name: r.name, pid: r.pid, cpu: round(r.delta / span * 100), memory: round(r.rss * PAGE_BYTES / GB2, 2) }));
      }
      lastProcs = now;
      lastJiffies = jiffies;
      if (mounts && dfText) {
        const sizes = parseDf(dfText);
        const drives = [];
        for (const m of parseMounts(mounts)) {
          const size = sizes.get(m.mount);
          if (!size) continue;
          const parent = parentDisk(m.device);
          const model = (await read(`/sys/block/${parent}/device/model`))?.trim();
          drives.push({
            id: m.device,
            name: m.mount === "/" ? "System" : m.mount,
            ...model ? { model } : {},
            total: round(size.total),
            used: round(size.used),
            free: round(size.free),
            usage: round(size.used / size.total * 100)
          });
          if (m.mount === "/") rootDisk = parent;
        }
        const io = rootDisk && diskstats ? parseDiskstats(diskstats, rootDisk) : null;
        const rate = io ? disk([io.read, io.write]) : null;
        const temp = sensors.has("nvme") ? await readNumber(`${sensors.get("nvme")}/temp1_input`) : void 0;
        const system = drives.find((d) => d.name === "System");
        if (system && rate) Object.assign(system, { readSpeed: round(rate[0] / 1e6), writeSpeed: round(rate[1] / 1e6) });
        if (system && temp !== void 0) system.temperature = round(temp / 1e3);
        section.storage = drives;
      }
      const ping = pingText ? parsePing(pingText) : void 0;
      section.network = { ...ping !== void 0 ? { ping } : {}, connected: iface !== null };
      for (const bat of await list("/sys/class/power_supply")) {
        if (!bat.startsWith("BAT")) continue;
        const base = `/sys/class/power_supply/${bat}`;
        const [capacity, status, cycles, full, design, chargeFull, chargeDesign] = await Promise.all([
          readNumber(`${base}/capacity`),
          read(`${base}/status`),
          readNumber(`${base}/cycle_count`),
          readNumber(`${base}/energy_full`),
          readNumber(`${base}/energy_full_design`),
          readNumber(`${base}/charge_full`),
          readNumber(`${base}/charge_full_design`)
        ]);
        if (capacity === void 0) continue;
        const now2 = full ?? chargeFull;
        const was = design ?? chargeDesign;
        section.battery = {
          percentage: capacity,
          charging: /charging|full/i.test(status ?? "") && !/discharging/i.test(status ?? ""),
          ...cycles ? { cycleCount: cycles } : {},
          ...now2 && was ? { health: Math.round(Math.min(100, now2 / was * 100)) } : {}
        };
        caps = { ...caps, battery: true };
        break;
      }
      return section;
    },
    async slow() {
      sensors = await hwmons();
      const [osRelease, info, routes, wireless, nvidiaText, cards] = await Promise.all([
        read("/etc/os-release"),
        read("/proc/cpuinfo"),
        read("/proc/net/route"),
        read("/proc/net/wireless"),
        run("nvidia-smi", [`--query-gpu=${NVIDIA_QUERY}`, "--format=csv,noheader,nounits"]),
        list("/sys/class/drm")
      ]);
      iface = routes ? parseDefaultRoute(routes) : iface;
      const os = osRelease ? parseOsRelease(osRelease) : void 0;
      const cpuInfo = info ? parseCpuinfo(info) : { model: void 0, cores: void 0 };
      const section = {
        device: { name: Deno.hostname(), version: os ?? "Linux", architecture: Deno.build.arch === "x86_64" ? "x64" : Deno.build.arch === "aarch64" ? "arm64" : Deno.build.arch },
        system: { hostname: Deno.hostname(), os: os ?? "Linux", kernel: Deno.osRelease(), uptime: Math.round(Deno.osUptime()) },
        cpu: { name: cpuInfo.model ?? cpus2()[0]?.model, cores: cpuInfo.cores, threads: cpus2().length }
      };
      const nv = nvidiaText ? parseNvidiaSmi(nvidiaText) : null;
      nvidia = !!nv;
      amd = null;
      if (!nvidia) {
        for (const card of cards.filter((c) => /^card\d+$/.test(c))) {
          const base = `/sys/class/drm/${card}/device`;
          if (await readNumber(`${base}/gpu_busy_percent`) === void 0) continue;
          const mons = await list(`${base}/hwmon`);
          amd = { base, hwmon: mons[0] ? `${base}/hwmon/${mons[0]}` : null };
          break;
        }
      }
      if (nv) section.gpu = { name: nv.name };
      else if (amd) section.gpu = { name: "AMD Radeon GPU" };
      caps = { ...caps, gpu: nvidia || !!amd, gpuTemperature: nvidia || !!amd?.hwmon };
      if (iface) {
        const addresses = Deno.networkInterfaces().filter((n) => n.name === iface);
        const speed = await readNumber(`/sys/class/net/${iface}/speed`);
        const level = wireless ? parseWireless(wireless, iface) : void 0;
        const wifi = level !== void 0 || iface.startsWith("wl");
        section.network = {
          interface: `${wifi ? "Wi-Fi" : "Ethernet"} (${iface})`,
          ip: addresses.find((a) => a.family === "IPv4")?.address,
          ipv6: addresses.find((a) => a.family === "IPv6" && !a.address.startsWith("fe80"))?.address,
          // a wireless driver answers -1 here; only a wired link knows its speed this way
          ...speed !== void 0 && speed > 0 ? { linkSpeed: speed } : {},
          ...level !== void 0 ? { signal: rssiPercent(level) } : {}
        };
      }
      return section;
    }
  };
}

// extension/collectors/macos.ts
import { cpus as cpus3 } from "node:os";
var BIN = {
  vmStat: "/usr/bin/vm_stat",
  sysctl: "/usr/sbin/sysctl",
  ioreg: "/usr/sbin/ioreg",
  netstat: "/usr/sbin/netstat",
  ps: "/bin/ps",
  pmset: "/usr/bin/pmset",
  df: "/bin/df",
  ping: "/sbin/ping",
  route: "/sbin/route",
  profiler: "/usr/sbin/system_profiler",
  swVers: "/usr/bin/sw_vers",
  scutil: "/usr/sbin/scutil",
  ifconfig: "/sbin/ifconfig",
  networksetup: "/usr/sbin/networksetup"
};
var PING_HOST2 = "1.1.1.1";
var PROCESS_COUNT2 = 25;
function memory(text2, totalBytes) {
  const page = after(text2, "page size of") ?? 16384;
  const pages = (label) => (after(text2, label) ?? 0) * page;
  const app = pages("Anonymous pages:") - pages("Pages purgeable:");
  const used = app + pages("Pages wired down:") + pages("Pages occupied by compressor:");
  const cached = pages("File-backed pages:") + pages("Pages purgeable:");
  return { used: used / GB, cached: cached / GB, available: (totalBytes - used) / GB, usage: used / totalBytes * 100 };
}
function swap(text2) {
  const mb = (label) => {
    const m = new RegExp(`${label} = ([\\d.]+)([MG])`).exec(text2);
    if (!m) return void 0;
    return Number(m[1]) / (m[2] === "G" ? 1 : 1024);
  };
  return { swapTotal: mb("total"), swapUsed: mb("used") };
}
function ioregNumber(text2, key) {
  const m = new RegExp(`"${key.replace(/[()%]/g, (c) => `\\${c}`)}"=(\\d+)`).exec(text2);
  return m ? Number(m[1]) : void 0;
}
function macosCollector() {
  const cpu = cpuMeter();
  let lastNet = null;
  let lastDisk = null;
  let iface = null;
  let totalBytes = 0;
  let internalModel;
  let caps = {
    cpu: true,
    cpuTemperature: false,
    gpu: false,
    gpuTemperature: false,
    memory: true,
    storage: true,
    network: true,
    battery: false,
    processes: true,
    displays: false
  };
  async function defaultInterface() {
    const out = await run(BIN.route, ["-n", "get", "default"]);
    const m = out && /interface:\s*(\S+)/.exec(out);
    iface = m ? m[1] : null;
  }
  return {
    capabilities: () => caps,
    async fast() {
      const now = Date.now();
      const { usage, perCoreUsage } = cpu();
      const [vm, swapText, gpuText, netText] = await Promise.all([
        run(BIN.vmStat, []),
        run(BIN.sysctl, ["-n", "vm.swapusage"]),
        run(BIN.ioreg, ["-r", "-d", "1", "-w0", "-c", "IOAccelerator"]),
        iface ? run(BIN.netstat, ["-ibn", "-I", iface]) : Promise.resolve(null)
      ]);
      const section = {
        cpu: { usage, perCoreUsage, load: Deno.loadavg().map((v) => round(v, 2)) },
        system: { uptime: Math.round(Deno.osUptime()) }
      };
      const speed = cpus3()[0]?.speed ?? 0;
      if (Deno.build.arch === "x86_64" && speed > 100 && section.cpu) section.cpu.frequency = speed;
      if (vm && totalBytes > 0) {
        const m = memory(vm, totalBytes);
        section.memory = { total: round(totalBytes / GB), used: round(m.used), available: round(m.available), cached: round(m.cached), usage: round(m.usage), ...swapText ? swap(swapText) : {} };
      }
      const gpuUse = gpuText ? ioregNumber(gpuText, "Device Utilization %") : void 0;
      if (gpuUse !== void 0) {
        const inUse = ioregNumber(gpuText, "In use system memory");
        section.gpu = { usage: gpuUse, ...inUse !== void 0 ? { memoryUsed: round(inUse / GB) } : {} };
      }
      const row = netText?.split("\n").find((l) => l.startsWith(`${iface} `) && l.includes("<Link#"));
      if (row) {
        const cols = row.trim().split(/\s+/);
        const rx = Number(cols[6]);
        const tx = Number(cols[9]);
        if (lastNet && now > lastNet.at && rx >= lastNet.rx && tx >= lastNet.tx) {
          const secs = (now - lastNet.at) / 1e3;
          section.network = { download: round((rx - lastNet.rx) * 8 / secs / 1e6, 2), upload: round((tx - lastNet.tx) * 8 / secs / 1e6, 2), connected: true };
        }
        lastNet = { at: now, rx, tx };
      }
      return section;
    },
    async medium() {
      await defaultInterface();
      const now = Date.now();
      const [psText, batt, dfText, pingText, diskText] = await Promise.all([
        run(BIN.ps, ["-Aceo", "pid=,pcpu=,rss=,comm=", "-r"]),
        run(BIN.pmset, ["-g", "batt"]),
        run(BIN.df, ["-k", "-P"]),
        run(BIN.ping, ["-c", "1", "-t", "2", PING_HOST2], 4e3),
        run(BIN.ioreg, ["-c", "IOBlockStorageDriver", "-r", "-w0", "-d", "1"])
      ]);
      const section = {};
      if (psText) {
        const procs = [];
        for (const line of psText.split("\n")) {
          const m = /^\s*(\d+)\s+([\d.]+)\s+(\d+)\s+(.+)$/.exec(line);
          if (m) procs.push({ pid: Number(m[1]), cpu: Number(m[2]), memory: round(Number(m[3]) / 1024 / 1024, 2), name: m[4].trim() });
          if (procs.length >= PROCESS_COUNT2) break;
        }
        section.processes = procs;
      }
      const battery = batt && /(\d+)%;\s*([a-z ]+);/i.exec(batt);
      if (battery) {
        section.battery = { percentage: Number(battery[1]), charging: battery[2].trim() === "charging" || batt.includes("'AC Power'") };
        caps = { ...caps, battery: true };
      }
      if (dfText) {
        const drives = [];
        let read2;
        let write;
        if (diskText) {
          const sum2 = (key) => [...diskText.matchAll(new RegExp(`"Bytes \\(${key}\\)"=(\\d+)`, "g"))].reduce((a, m) => a + Number(m[1]), 0);
          const r = sum2("Read");
          const w = sum2("Write");
          if (lastDisk && now > lastDisk.at && r >= lastDisk.read && w >= lastDisk.write) {
            const secs = (now - lastDisk.at) / 1e3;
            read2 = round((r - lastDisk.read) / secs / 1e6);
            write = round((w - lastDisk.write) / secs / 1e6);
          }
          lastDisk = { at: now, read: r, write: w };
        }
        for (const line of dfText.split("\n").slice(1)) {
          const cols = line.trim().split(/\s+/);
          if (cols.length < 6) continue;
          const mount = cols.slice(5).join(" ");
          const isData = mount === "/System/Volumes/Data";
          const isExternal = mount.startsWith("/Volumes/") && !mount.includes("TimeMachine");
          if (!isData && !isExternal) continue;
          const total = Number(cols[1]) / 1024 / 1024;
          const free = Number(cols[3]) / 1024 / 1024;
          const used = total - free;
          drives.push({
            id: cols[0],
            name: isData ? "Macintosh HD" : mount.slice("/Volumes/".length),
            ...isData && internalModel ? { model: internalModel } : {},
            total: round(total),
            used: round(used),
            free: round(free),
            usage: round(used / total * 100),
            // the block counters are for the internal drive; an external one gets its own figures later
            ...isData && read2 !== void 0 ? { readSpeed: read2, writeSpeed: write } : {}
          });
        }
        section.storage = drives;
      }
      const ping = pingText ? /time=([\d.]+)/.exec(pingText) : null;
      section.network = { ...ping ? { ping: round(Number(ping[1])) } : {}, connected: iface !== null };
      return section;
    },
    async slow() {
      if (!iface) await defaultInterface();
      const [brand, physical, logical, memsize, version, computerName, ports, displays, airport, power, nvme, media] = await Promise.all([
        run(BIN.sysctl, ["-n", "machdep.cpu.brand_string"]),
        run(BIN.sysctl, ["-n", "hw.physicalcpu"]),
        run(BIN.sysctl, ["-n", "hw.logicalcpu"]),
        run(BIN.sysctl, ["-n", "hw.memsize"]),
        run(BIN.swVers, ["-productVersion"]),
        run(BIN.scutil, ["--get", "ComputerName"]),
        run(BIN.networksetup, ["-listallhardwareports"]),
        runJson(BIN.profiler, ["SPDisplaysDataType", "-json"]),
        runJson(BIN.profiler, ["SPAirPortDataType", "-json"]),
        runJson(BIN.profiler, ["SPPowerDataType", "-json"]),
        runJson(BIN.profiler, ["SPNVMeDataType", "-json"]),
        iface ? run(BIN.ifconfig, [iface]) : Promise.resolve(null)
      ]);
      totalBytes = Number(memsize) || totalBytes;
      const section = {
        device: { name: computerName?.trim() || Deno.hostname(), version: version ? `macOS ${version.trim()}` : "macOS", architecture: Deno.build.arch === "aarch64" ? "arm64" : Deno.build.arch },
        system: { hostname: Deno.hostname(), os: version ? `macOS ${version.trim()}` : "macOS", kernel: `Darwin ${Deno.osRelease()}`, uptime: Math.round(Deno.osUptime()) },
        cpu: { name: brand?.trim() || cpus3()[0]?.model, cores: Number(physical) || void 0, threads: Number(logical) || void 0 }
      };
      const card = displays?.SPDisplaysDataType?.[0];
      if (card) {
        const name = card.sppci_model ? `${card.sppci_model} GPU${card.sppci_cores ? ` (${card.sppci_cores}-core)` : ""}` : void 0;
        section.gpu = { name };
        caps = { ...caps, gpu: true };
        const list2 = (card.spdisplays_ndrvs ?? []).map((d) => {
          const px = /(\d+)\s*x\s*(\d+)/.exec(d._spdisplays_pixels ?? d._spdisplays_resolution ?? "");
          const hz = /@\s*([\d.]+)Hz/.exec(d._spdisplays_resolution ?? "");
          return { name: d._name, width: px ? Number(px[1]) : void 0, height: px ? Number(px[2]) : void 0, refreshRate: hz ? Math.round(Number(hz[1])) : void 0 };
        });
        if (list2.length) {
          section.displays = list2;
          caps = { ...caps, displays: true };
        }
      }
      const portName = ports && iface ? new RegExp(`Hardware Port: (.+)\\nDevice: ${iface}\\b`).exec(ports)?.[1] : void 0;
      const addresses = Deno.networkInterfaces().filter((n) => n.name === iface);
      section.network = {
        interface: portName ? `${portName} (${iface})` : iface ?? void 0,
        ip: addresses.find((a) => a.family === "IPv4")?.address,
        ipv6: addresses.find((a) => a.family === "IPv6" && !a.address.startsWith("fe80"))?.address
      };
      const wifi = airport?.SPAirPortDataType?.[0]?.spairport_airport_interfaces?.find((i) => i._name === iface)?.spairport_current_network_information;
      if (wifi?.spairport_network_rate) section.network.linkSpeed = wifi.spairport_network_rate;
      const rssi = wifi?.spairport_signal_noise ? /(-\d+)\s*dBm/.exec(wifi.spairport_signal_noise) : null;
      if (rssi) section.network.signal = rssiPercent(Number(rssi[1]));
      const wired = media ? /media:.*?(\d+)base/.exec(media) : null;
      if (!section.network.linkSpeed && wired) section.network.linkSpeed = Number(wired[1]);
      const health = power?.SPPowerDataType?.find((p) => p.sppower_battery_health_info)?.sppower_battery_health_info;
      if (health) {
        section.battery = {
          cycleCount: health.sppower_battery_cycle_count,
          health: health.sppower_battery_health_maximum_capacity ? Number.parseInt(health.sppower_battery_health_maximum_capacity, 10) : void 0
        };
      }
      internalModel = nvme?.SPNVMeDataType?.flatMap((c) => c._items ?? [])[0]?.device_model ?? internalModel;
      return section;
    }
  };
}

// extension/collectors/windows-script.ts
function windowsScript(intervalMs) {
  const interval = Math.max(500, Math.min(1e4, Math.round(intervalMs)));
  return `
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$interval = ${interval}
$tick = 0
$nvsmi = (Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue).Source
$pinger = New-Object System.Net.NetworkInformation.Ping
$ifIndex = $null
$ifName = $null

function Find-Route {
  $r = Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort-Object { $_.RouteMetric + $_.InterfaceMetric } | Select-Object -First 1
  if ($r) {
    $script:ifIndex = $r.InterfaceIndex
    $script:ifName = (Get-NetAdapter -InterfaceIndex $r.InterfaceIndex).Name
  }
}
Find-Route

while ($true) {
  $started = Get-Date
  $o = @{ tick = $tick; fast = @{} }

  if ($ifName) {
    $s = Get-NetAdapterStatistics -Name $ifName
    if ($s) { $o.fast.rx = [double]$s.ReceivedBytes; $o.fast.tx = [double]$s.SentBytes }
  }
  $perf = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'"
  if ($perf) { $o.fast.cpuPerf = [double]$perf.PercentProcessorPerformance }
  if ($nvsmi) { $o.fast.nvidia = (& $nvsmi --query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total,clocks.gr,power.draw,fan.speed --format=csv,noheader,nounits | Out-String) }

  if ($tick % 5 -eq 0) {
    Find-Route
    $m = @{}
    $m.processes = @(Get-CimInstance Win32_PerfFormattedData_PerfProc_Process |
      Where-Object { $_.Name -ne '_Total' -and $_.Name -ne 'Idle' } |
      Sort-Object PercentProcessorTime -Descending | Select-Object -First 25 |
      ForEach-Object { @{ name = $_.Name; pid = [int]$_.IDProcess; cpu = [double]$_.PercentProcessorTime; bytes = [double]$_.WorkingSetPrivate } })
    $m.disks = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' |
      ForEach-Object { @{ id = $_.DeviceID; label = $_.VolumeName; size = [double]$_.Size; free = [double]$_.FreeSpace } })
    $io = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'"
    if ($io) { $m.readBps = [double]$io.DiskReadBytesPersec; $m.writeBps = [double]$io.DiskWriteBytesPersec }
    $b = Get-CimInstance Win32_Battery | Select-Object -First 1
    if ($b) { $m.battery = @{ percent = [int]$b.EstimatedChargeRemaining; status = [int]$b.BatteryStatus } }
    $mem = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    if ($mem) { $m.cachedBytes = [double]$mem.StandbyCacheCoreBytes + [double]$mem.StandbyCacheNormalPriorityBytes + [double]$mem.StandbyCacheReserveBytes + [double]$mem.ModifiedPageListBytes }
    try { $p = $pinger.Send('1.1.1.1', 2000); if ($p.Status -eq 'Success') { $m.ping = [double]$p.RoundtripTime } } catch {}
    $wlan = (netsh wlan show interfaces | Out-String)
    if ($wlan) { $m.wlan = $wlan }
    if (-not $nvsmi) {
      $engines = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine | Where-Object { $_.Name -like '*engtype_3D*' }
      if ($engines) { $m.gpuUsage = [double](($engines | Measure-Object -Property UtilizationPercentage -Sum).Sum) }
    }
    $o.medium = $m
  }

  if ($tick % 30 -eq 0) {
    $sl = @{}
    $os = Get-CimInstance Win32_OperatingSystem
    if ($os) { $sl.os = $os.Caption; $sl.version = $os.Version; $sl.build = $os.BuildNumber }
    $cpus = @(Get-CimInstance Win32_Processor)
    if ($cpus.Count -gt 0) {
      $sl.cpu = @{ name = $cpus[0].Name.Trim(); cores = [int](($cpus | Measure-Object -Property NumberOfCores -Sum).Sum); threads = [int](($cpus | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum); maxMhz = [int]$cpus[0].MaxClockSpeed }
    }
    $sl.gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { @{ name = $_.Name; width = [int]$_.CurrentHorizontalResolution; height = [int]$_.CurrentVerticalResolution; hz = [int]$_.CurrentRefreshRate } })
    if ($ifIndex) {
      $a = Get-NetAdapter -InterfaceIndex $ifIndex
      if ($a) { $sl.adapter = @{ name = $a.Name; description = $a.InterfaceDescription; bps = [double]$a.ReceiveLinkSpeed; media = [string]$a.PhysicalMediaType } }
      $sl.ips = @(Get-NetIPAddress -InterfaceIndex $ifIndex | ForEach-Object { @{ address = $_.IPAddress; family = [string]$_.AddressFamily } })
    }
    $sl.models = @{}
    foreach ($d in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
      $part = Get-Partition -DriveLetter $d.DeviceID.Substring(0, 1)
      if ($part) {
        $disk = Get-PhysicalDisk | Where-Object { $_.DeviceId -eq [string]$part.DiskNumber } | Select-Object -First 1
        if ($disk) { $sl.models[$d.DeviceID] = $disk.FriendlyName }
      }
    }
    $full = (Get-CimInstance -Namespace root\\wmi -ClassName BatteryFullChargedCapacity | Select-Object -First 1).FullChargedCapacity
    $design = (Get-CimInstance -Namespace root\\wmi -ClassName BatteryStaticData | Select-Object -First 1).DesignedCapacity
    $cycles = (Get-CimInstance -Namespace root\\wmi -ClassName BatteryCycleCount | Select-Object -First 1).CycleCount
    if ($full -and $design) { $sl.batteryHealth = [int](100 * $full / $design) }
    if ($cycles) { $sl.batteryCycles = [int]$cycles }
    $o.slow = $sl
  }

  [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress -Depth 6))
  [Console]::Out.Flush()
  $tick++
  $spent = ((Get-Date) - $started).TotalMilliseconds
  Start-Sleep -Milliseconds ([int][Math]::Max(50, $interval - $spent))
}
`;
}
function encodePowerShell(script) {
  const bytes = new Uint8Array(script.length * 2);
  for (let i = 0; i < script.length; i++) {
    const c = script.charCodeAt(i);
    bytes[i * 2] = c & 255;
    bytes[i * 2 + 1] = c >> 8;
  }
  let binary2 = "";
  for (let i = 0; i < bytes.length; i += 32768) binary2 += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(binary2);
}

// extension/collectors/windows-parse.ts
var GB3 = 1024 ** 3;
function many(v) {
  if (Array.isArray(v)) return v;
  return v && typeof v === "object" ? [v] : [];
}
var num = (v) => typeof v === "number" && Number.isFinite(v) ? v : void 0;
var str = (v) => typeof v === "string" && v.trim() ? v.trim() : void 0;
function parseLine(text2) {
  try {
    const v = JSON.parse(text2);
    return v && typeof v === "object" && typeof v.tick === "number" && v.fast && typeof v.fast === "object" ? v : null;
  } catch {
    return null;
  }
}
function mapFast(fast, maxMhz) {
  const section = {};
  const perf = num(fast.cpuPerf);
  if (perf !== void 0 && maxMhz) section.cpu = { frequency: Math.round(maxMhz * perf / 100) };
  const gpu = str(fast.nvidia) ? parseNvidiaSmi(fast.nvidia) : null;
  if (gpu) section.gpu = gpu;
  return section;
}
function wlanSignal(text2) {
  const m = /:\s*(\d{1,3})\s*%/.exec(text2);
  return m ? Math.min(100, Number(m[1])) : void 0;
}
function wlanRate(text2) {
  const m = /\(Mbps\)\s*:\s*([\d.]+)/.exec(text2);
  return m ? Number(m[1]) : void 0;
}
var processName = (name) => name.replace(/#\d+$/, "");
function mapMedium(m, models) {
  const section = {};
  const procs = many(m.processes).map((p) => {
    const name = str(p.name);
    if (!name) return null;
    return { name: processName(name), pid: num(p.pid), cpu: num(p.cpu), memory: num(p.bytes) === void 0 ? void 0 : round(num(p.bytes) / GB3, 2) };
  }).filter((p) => p !== null);
  if (procs.length) section.processes = procs;
  const drives = many(m.disks).map((d) => {
    const id = str(d.id);
    const size = num(d.size);
    const free = num(d.free);
    if (!id || !size || free === void 0) return null;
    const label = str(d.label);
    return {
      id,
      name: label ? `${label} (${id})` : `Local Disk (${id})`,
      ...models[id] ? { model: models[id] } : {},
      total: round(size / GB3),
      used: round((size - free) / GB3),
      free: round(free / GB3),
      usage: round((size - free) / size * 100)
    };
  }).filter((d) => d !== null);
  const system = drives.find((d) => d.id === "C:") ?? drives[0];
  if (system && num(m.readBps) !== void 0) {
    system.readSpeed = round(num(m.readBps) / 1e6);
    system.writeSpeed = round((num(m.writeBps) ?? 0) / 1e6);
  }
  if (drives.length) section.storage = drives;
  const pct = num(m.battery?.percent);
  if (pct !== void 0) {
    const status = num(m.battery?.status);
    section.battery = { percentage: pct, charging: status !== void 0 && status !== 1 && status !== 4 && status !== 5 };
  }
  const ping = num(m.ping);
  const signal = str(m.wlan) ? wlanSignal(m.wlan) : void 0;
  section.network = {
    ...ping !== void 0 ? { ping } : {},
    ...signal !== void 0 ? { signal } : {}
  };
  const gpuUsage = num(m.gpuUsage);
  if (gpuUsage !== void 0) section.gpu = { usage: Math.min(100, Math.round(gpuUsage)) };
  return section;
}
function mapSlow(s) {
  const section = {};
  const os = str(s.os);
  const version = os ? `${os.replace(/^Microsoft\s+/, "")}${s.build ? ` (build ${s.build})` : ""}` : void 0;
  section.device = { ...version ? { version } : {} };
  section.system = { ...os ? { os: os.replace(/^Microsoft\s+/, "") } : {}, ...str(s.version) ? { kernel: `NT ${s.version}` } : {} };
  if (s.cpu) section.cpu = { name: str(s.cpu.name), cores: num(s.cpu.cores), threads: num(s.cpu.threads) };
  const gpus = many(s.gpus);
  const real = gpus.find((g) => str(g.name) && !/basic display|remote|virtual/i.test(String(g.name)));
  if (real) section.gpu = { name: str(real.name) };
  const displays = gpus.filter((g) => num(g.width)).map((g) => ({ name: str(g.name), width: num(g.width), height: num(g.height), refreshRate: num(g.hz) }));
  if (displays.length) section.displays = displays;
  const ips = many(s.ips);
  const v4 = ips.find((i) => String(i.family).includes("IPv4") || String(i.family) === "2");
  const v6 = ips.find((i) => (String(i.family).includes("IPv6") || String(i.family) === "23") && !String(i.address).startsWith("fe80"));
  const bps = num(s.adapter?.bps);
  const wifi = /802\.11|wireless|wi-?fi/i.test(`${s.adapter?.media ?? ""} ${s.adapter?.description ?? ""}`);
  section.network = {
    ...str(s.adapter?.name) ? { interface: `${wifi ? "Wi-Fi" : "Ethernet"} (${str(s.adapter?.name)})` } : {},
    ...str(v4?.address) ? { ip: str(v4?.address) } : {},
    ...str(v6?.address) ? { ipv6: str(v6?.address) } : {},
    ...bps ? { linkSpeed: Math.round(bps / 1e6) } : {}
  };
  if (num(s.batteryHealth) !== void 0 || num(s.batteryCycles) !== void 0) {
    section.battery = {
      ...num(s.batteryHealth) !== void 0 ? { health: Math.min(100, num(s.batteryHealth)) } : {},
      ...num(s.batteryCycles) !== void 0 ? { cycleCount: num(s.batteryCycles) } : {}
    };
  }
  return section;
}

// extension/collectors/windows.ts
var POWERSHELL = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe";
var GB4 = 1024 ** 3;
var RESTART_MS = 5e3;
function windowsCollector(log) {
  const cpu = cpuMeter();
  const net = rateMeter();
  let interval = 1e3;
  let child = null;
  let stopped = false;
  let active = false;
  let restart;
  let fast = {};
  let medium = {};
  let slow = {};
  let rawMedium;
  let models = {};
  let maxMhz;
  let caps = {
    cpu: true,
    cpuTemperature: false,
    gpu: false,
    gpuTemperature: false,
    memory: true,
    storage: true,
    network: true,
    battery: false,
    processes: true,
    displays: false
  };
  const take = (line) => {
    if (line.slow) {
      slow = mapSlow(line.slow);
      models = line.slow.models ?? models;
      maxMhz = line.slow.cpu?.maxMhz ?? maxMhz;
      caps = { ...caps, gpu: caps.gpu || !!slow.gpu, displays: !!slow.displays?.length };
      if (!slow.network?.linkSpeed && rawMedium?.wlan) {
        const rate = wlanRate(rawMedium.wlan);
        if (rate) slow.network = { ...slow.network, linkSpeed: rate };
      }
    }
    if (line.medium) {
      rawMedium = line.medium;
      medium = mapMedium(line.medium, models);
      if (medium.battery) caps = { ...caps, battery: true };
      if (medium.gpu) caps = { ...caps, gpu: true };
    }
    const next = mapFast(line.fast, maxMhz);
    if (next.gpu) caps = { ...caps, gpu: true, gpuTemperature: next.gpu.temperature !== void 0 };
    const rx = line.fast.rx;
    const tx = line.fast.tx;
    if (typeof rx === "number" && typeof tx === "number") {
      const rate = net([rx, tx]);
      if (rate) next.network = { download: mbps(rate[0]), upload: mbps(rate[1]), connected: true };
    }
    fast = next;
  };
  async function pump(proc) {
    const reader = proc.stdout.getReader();
    const decoder2 = new TextDecoder();
    let buffer = "";
    try {
      for (; ; ) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder2.decode(value, { stream: true });
        let at;
        while ((at = buffer.indexOf("\n")) !== -1) {
          const text2 = buffer.slice(0, at).trim();
          buffer = buffer.slice(at + 1);
          const line = text2 ? parseLine(text2) : null;
          if (line) take(line);
        }
      }
    } catch {
    }
  }
  function start() {
    if (stopped || !active || child) return;
    try {
      child = new Deno.Command(POWERSHELL, {
        args: ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encodePowerShell(windowsScript(interval))],
        stdout: "piped",
        stderr: "null",
        stdin: "null"
      }).spawn();
    } catch (err) {
      log("powershell would not start", String(err));
      restart = setTimeout(start, RESTART_MS);
      return;
    }
    const proc = child;
    void pump(proc);
    proc.status.then(() => {
      if (child === proc) child = null;
      if (!stopped && active) restart = setTimeout(start, RESTART_MS);
    });
  }
  function kill() {
    clearTimeout(restart);
    const proc = child;
    child = null;
    try {
      proc?.kill();
    } catch {
    }
  }
  return {
    streaming: true,
    capabilities: () => caps,
    async fast() {
      const { usage, perCoreUsage } = cpu();
      const m = Deno.systemMemoryInfo();
      const used = m.total - m.available;
      const cached = rawMedium?.cachedBytes;
      return {
        ...fast,
        cpu: { ...fast.cpu, usage, perCoreUsage },
        memory: {
          total: round(m.total / GB4),
          used: round(used / GB4),
          available: round(m.available / GB4),
          usage: round(used / m.total * 100),
          ...typeof cached === "number" ? { cached: round(cached / GB4) } : {},
          // deno reads the page file as swap on windows
          ...m.swapTotal > 0 ? { swapTotal: round(m.swapTotal / GB4), swapUsed: round((m.swapTotal - m.swapFree) / GB4) } : {}
        },
        system: { uptime: Math.round(Deno.osUptime()) }
      };
    },
    async medium() {
      return medium;
    },
    async slow() {
      return {
        ...slow,
        device: { name: Deno.hostname(), architecture: Deno.build.arch === "x86_64" ? "x64" : Deno.build.arch === "aarch64" ? "arm64" : Deno.build.arch, ...slow.device },
        system: { hostname: Deno.hostname(), ...slow.system }
      };
    },
    setInterval(ms) {
      if (ms === interval) return;
      interval = ms;
      kill();
      start();
    },
    setActive(on) {
      if (on === active) return;
      active = on;
      if (on) start();
      else kill();
    },
    stop() {
      stopped = true;
      kill();
    }
  };
}

// extension/main.ts
var MIN_INTERVAL = 1e3;
var MAX_INTERVAL = 5e3;
var MEDIUM_EVERY = 5;
var SLOW_EVERY = 30;
function collectorFor(os, log) {
  if (os === "darwin") return { platform: "macos", collector: macosCollector() };
  if (os === "linux") return { platform: "linux", collector: linuxCollector() };
  if (os === "windows") return { platform: "windows", collector: windowsCollector(log) };
  return null;
}
function merge(...parts) {
  const out = {};
  for (const part of parts) {
    for (const [key, value] of Object.entries(part)) {
      if (value === void 0) continue;
      const prev = out[key];
      out[key] = value && typeof value === "object" && !Array.isArray(value) && prev && typeof prev === "object" && !Array.isArray(prev) ? { ...prev, ...value } : value;
    }
  }
  return out;
}
var timer;
var running = null;
defineExtension({
  start(ctx) {
    const found = collectorFor(Deno.build.os, (...args) => ctx.log.warn(...args));
    running = found?.collector ?? null;
    let interval = MIN_INTERVAL;
    let deviceId = null;
    let slow = {};
    let medium = {};
    let tick = 0;
    let busy2 = false;
    const watching = () => ctx.devices.some((d) => d.connected && d.active);
    const hello = () => ctx.broadcast(
      json({
        type: "hello",
        role: "agent",
        protocol: PROTOCOL_VERSION,
        ...found && deviceId ? { devices: [{ id: deviceId, name: String(slow.device?.name ?? Deno.hostname()), platform: found.platform, online: true }] } : {}
      })
    );
    const sendCapabilities = () => {
      if (found && deviceId) ctx.broadcast(json({ type: "capabilities", deviceId, capabilities: found.collector.capabilities() }));
    };
    ctx.on("device", (event) => {
      if (event.type === "disconnected") return;
      hello();
      sendCapabilities();
    });
    ctx.on("message", (_device, message) => {
      const payload = asJson(message);
      if (payload?.type !== "hello") return;
      if (typeof payload.interval === "number" && Number.isFinite(payload.interval)) {
        interval = Math.min(MAX_INTERVAL, Math.max(MIN_INTERVAL, Math.round(payload.interval)));
        found?.collector.setInterval?.(interval);
      }
      hello();
      sendCapabilities();
    });
    if (!found) {
      ctx.log.warn(`no collector for ${Deno.build.os} yet`);
      ctx.broadcast(json({ type: "error", message: `This computer (${Deno.build.os}) is not supported yet` }));
      return;
    }
    const { platform, collector } = found;
    const frame = async () => {
      const on = watching();
      collector.setActive?.(on);
      if (!busy2 && deviceId && on) {
        busy2 = true;
        try {
          if (collector.streaming || tick % SLOW_EVERY === 0) slow = await collector.slow();
          if (collector.streaming || tick % MEDIUM_EVERY === 0) medium = await collector.medium();
          const fast = await collector.fast();
          const now = Date.now();
          const merged = merge(slow, medium, fast);
          const data = {
            ...merged,
            device: { online: true, ...merged.device, id: deviceId, name: String(merged.device?.name ?? Deno.hostname()), platform },
            system: { ...merged.system, timestamp: now }
          };
          const caps = collector.capabilities();
          if (!caps.gpu) data.gpu = null;
          if (!caps.battery) data.battery = null;
          if (tick === 0) sendCapabilities();
          ctx.broadcast(json({ type: "telemetry", timestamp: now, deviceId, data }));
          tick++;
        } catch (err) {
          ctx.log.warn("collection failed", String(err));
        } finally {
          busy2 = false;
        }
      }
      timer = setTimeout(frame, interval);
    };
    ctx.kv.get("deviceId").then(async (stored) => {
      deviceId = stored ?? `${platform}-${crypto.randomUUID().slice(0, 8)}`;
      if (!stored) await ctx.kv.set("deviceId", deviceId);
      ctx.log.info(`agent up on ${platform} as ${deviceId}`);
      hello();
      void frame();
    }).catch((err) => ctx.log.error("could not read the device id", String(err)));
  },
  stop() {
    clearTimeout(timer);
    running?.stop?.();
  }
});
